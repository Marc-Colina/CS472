// app.js

const person = require("./pattern");

person.getName();

person.getDate();
