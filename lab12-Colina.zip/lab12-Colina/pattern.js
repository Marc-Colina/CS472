module.exports.getName = function () {
  console.log("Josh Edward");
};

exports.getDate = function () {
  console.log("2024-04-18");
};
